# X-ray-Dental-Detection
this is an AI tool useful in dental feild
#this system gets a input x-ray image from the user and detects the defected areas in the image. this system is under construction. originally will be developed in React-js and will use backend as 
python that includes AI techniques
